INSERT INTO PRODUCTS VALUES (NEXT VALUE FOR HIBERNATE_SEQUENCE, 'MacBook Air', '125000', 'Best Laptop', 'LAPTOP', 'macbook_air.jpg', 50);
INSERT INTO PRODUCTS VALUES (NEXT VALUE FOR HIBERNATE_SEQUENCE, 'Predator Helios 300', '140000', 'Best Gaming Laptop', 'LAPTOP', 'predator_helios_300.jpg', 50);
INSERT INTO PRODUCTS VALUES (NEXT VALUE FOR HIBERNATE_SEQUENCE, 'iPhone 13', '80000', 'Best Mobile phone', 'MOBILE_PHONES', 'iphone13.jpg', 45);
INSERT INTO PRODUCTS VALUES (NEXT VALUE FOR HIBERNATE_SEQUENCE, 'Apple Airpods Pro', '20000', 'Best bluetooth earpods', 'EARPHONES', 'apple_airpods_pro.jpg', 40);
INSERT INTO PRODUCTS VALUES (NEXT VALUE FOR HIBERNATE_SEQUENCE, 'Apple iMac Pro', '125000', 'Best Desktop', 'DESKTOP', 'imac.jpg', 35);
INSERT INTO PRODUCTS VALUES (NEXT VALUE FOR HIBERNATE_SEQUENCE, 'iWatch Series 7', '40000', 'Best Watches', 'WATCH', 'iwatch7.jpg', 30);

INSERT INTO PRODUCTS VALUES (NEXT VALUE FOR HIBERNATE_SEQUENCE, 'NIKE Shoes', '2029', 'Revolution 5 Running shoes for woman', 'SHOES', 'nike_shoes.jpg', 50);
INSERT INTO PRODUCTS VALUES (NEXT VALUE FOR HIBERNATE_SEQUENCE, 'Allen Solly Shirt', '3500', 'Best Self Designed formal Men Full Sleeve', 'SHIRT', 'shirt.jpg', 50);
INSERT INTO PRODUCTS VALUES (NEXT VALUE FOR HIBERNATE_SEQUENCE, 'Boat Storm', '2499', '1.3 inch Curved Display Smart Watch, (Grey strap,Regular)', 'FASHION', 'boat_watch.jpg', 50);
INSERT INTO PRODUCTS VALUES (NEXT VALUE FOR HIBERNATE_SEQUENCE, 'Realme Narzo 50i', '5999', 'realme narzo 50i ,Carbon Black,32Gb , 2GB Ram', 'MOBILE_PHONES', 'realme_narzo.jpg', 50);
INSERT INTO PRODUCTS VALUES (NEXT VALUE FOR HIBERNATE_SEQUENCE, 'REDMI 9i Sport', '8799', '13mp Camera, 5000 mah battery,Helio G25 ,4Gb Ram , 64GB ROM', 'MOBILE_PHONES', 'redmi_9i.jpg', 50);
INSERT INTO PRODUCTS VALUES (NEXT VALUE FOR HIBERNATE_SEQUENCE, 'Infinix Note 11', '10499', '5000mah battery, 6.7 inch display, 50mp + 2 mp + AI lens', 'MOBILE_PHONES', 'infinix_note11.jpg', 50);
INSERT INTO PRODUCTS VALUES (NEXT VALUE FOR HIBERNATE_SEQUENCE, 'Fastrack Sunglass', '1999', 'UV protection,Wayfarer Sunglasses, Free Size', 'FASHION', 'fastrack_sunglass.jpg', 50);
INSERT INTO PRODUCTS VALUES (NEXT VALUE FOR HIBERNATE_SEQUENCE, 'AISLIN', '5999', 'Polarized UV Protection, Rectangular Sunglasses', 'FASHION', 'sunglass.jpg', 50);
INSERT INTO PRODUCTS VALUES (NEXT VALUE FOR HIBERNATE_SEQUENCE, 'THE MAN COMPANY', '531', 'Skin Brightening cream, multani mitti coco butter, Defence Theory', 'CREAM', 'themancompany_cream.jpg', 50);
INSERT INTO PRODUCTS VALUES (NEXT VALUE FOR HIBERNATE_SEQUENCE, 'JACK & JONES', '5849', 'SKINNY MEN BLUE JEANS , COMFORTABLE', 'FASHION', 'jackandjones_jeans.jpg', 50);
INSERT INTO PRODUCTS VALUES (NEXT VALUE FOR HIBERNATE_SEQUENCE, 'DIESEL', '32459', 'ANALOG watch for Men', 'WATCH', 'dieselwatch.jpg', 50);

INSERT INTO PRODUCTS VALUES (NEXT VALUE FOR HIBERNATE_SEQUENCE, 'iPhone 13', '80000', 'Best Mobile phone', 'TOP_OFFERS', 'iphone13.jpg', 45);
INSERT INTO PRODUCTS VALUES (NEXT VALUE FOR HIBERNATE_SEQUENCE, 'Predator Helios 300', '140000', 'Best Gaming Laptop', 'TOP_OFFERS', 'predator_helios_300.jpg', 50);
INSERT INTO PRODUCTS VALUES (NEXT VALUE FOR HIBERNATE_SEQUENCE, 'THE MAN COMPANY', '531', 'Skin Brightening cream, multani mitti coco butter, Defence Theory', 'TOP_OFFERS', 'themancompany_cream.jpg', 50);