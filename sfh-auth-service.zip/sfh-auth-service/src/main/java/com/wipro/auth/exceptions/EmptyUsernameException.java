package com.wipro.auth.exceptions;

public class EmptyUsernameException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
