package com.wipro.auth.exceptions;

public class EmptyPasswordException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
