package com.wipro.auth.exceptions;

public class ExistingUserException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
