package com.wipro.auth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SfhAuthServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SfhAuthServiceApplication.class, args);
	}

}
